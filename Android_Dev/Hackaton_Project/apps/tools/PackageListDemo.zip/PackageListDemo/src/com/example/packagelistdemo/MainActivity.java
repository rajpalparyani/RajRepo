package com.example.packagelistdemo;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        // Use an existing ListAdapter that will map an array
        // of strings to TextViews
        PackageManager pm = getPackageManager();
        List installedPackage = pm.getInstalledPackages(0);
        setContentView(R.layout.activity_main);
        
        ListView list = (ListView) findViewById(R.id.listView1);
        ArrayList tempList = new ArrayList(installedPackage);
        PackageListAdapter adapter = new PackageListAdapter();
        adapter.setPackageList(tempList);
        list.setAdapter(adapter);
        super.onCreate(savedInstanceState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    class PackageListAdapter implements ListAdapter

    {
        ArrayList<PackageInfo> packageList = new ArrayList<PackageInfo>();

        public void setPackageList(ArrayList<PackageInfo> info)
        {
            this.packageList = info;
        }

        public void registerDataSetObserver(DataSetObserver observer)
        {
            // TODO Auto-generated method stub

        }

        public void unregisterDataSetObserver(DataSetObserver observer)
        {
            // TODO Auto-generated method stub

        }

        public int getCount()
        {
            // TODO Auto-generated method stub
            return packageList.size();
        }

        public Object getItem(int position)
        {
            // TODO Auto-generated method stub
            return null;
        }

        public long getItemId(int position)
        {
            // TODO Auto-generated method stub
            return 0;
        }

        public boolean hasStableIds()
        {
            // TODO Auto-generated method stub
            return false;
        }

        public View getView(int position, View convertView, ViewGroup parent)
        {
            if(convertView == null)
            {
                LinearLayout rootItem = new LinearLayout(MainActivity.this);
                rootItem.setVerticalGravity(LinearLayout.HORIZONTAL);
                rootItem.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));
                
                ImageView icon = new ImageView(MainActivity.this);
                icon.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
                icon.setImageDrawable(this.packageList.get(position).applicationInfo.loadIcon(MainActivity.this.getPackageManager()));
                icon.setPadding(10, 0, 10, 0);
                
                TextView appName = new TextView(MainActivity.this);
                appName.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
                appName.setText(this.packageList.get(position).applicationInfo.loadLabel(MainActivity.this.getPackageManager()).toString().trim());
                appName.setPadding(10, 0, 10, 0);
                
                TextView version = new TextView(MainActivity.this);
                version.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
                version.setText(this.packageList.get(position).versionName);
                version.setPadding(10, 0, 10, 0);
                
                rootItem.addView(icon);
                rootItem.addView(appName);
                rootItem.addView(version);
                return rootItem;
            }
            else
            {
                ImageView icon = (ImageView) ((LinearLayout)convertView).getChildAt(0);
                TextView appName = (TextView) ((LinearLayout)convertView).getChildAt(1);
                TextView version = (TextView) ((LinearLayout)convertView).getChildAt(2);
                icon.setImageDrawable(this.packageList.get(position).applicationInfo.loadIcon(MainActivity.this.getPackageManager()));
                appName.setText(this.packageList.get(position).applicationInfo.loadLabel(MainActivity.this.getPackageManager()).toString().trim());
                version.setText(this.packageList.get(position).versionName);
                return convertView;
            }
        }

        public int getItemViewType(int position)
        {
            // TODO Auto-generated method stub
            return 0;
        }

        public int getViewTypeCount()
        {
            // TODO Auto-generated method stub
            return 1;
        }

        public boolean isEmpty()
        {
            // TODO Auto-generated method stub
            return packageList.size() < 1;
        }

        public boolean areAllItemsEnabled()
        {
            // TODO Auto-generated method stub
            return false;
        }

        public boolean isEnabled(int position)
        {
            // TODO Auto-generated method stub
            return false;
        }
    }
}
